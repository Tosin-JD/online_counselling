from django.db import models
from django.utils.text import slugify
from accounts.models import Counsellor

# Create your models here.
    
class Booking(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    date = models.CharField(max_length=30)
    time = models.CharField(max_length=30)
    purpose = models.CharField(max_length=50)
    message = models.TextField()
    whom_to_see = models.ForeignKey(Counsellor, on_delete=models.CASCADE)
    
    
    def __str__(self):
        return '{} coming on {} at {}.'.format(self.name, self.date, self.time)








        
        
            
        
    