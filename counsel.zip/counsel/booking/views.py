from django.shortcuts import render
from booking.models import Booking
from django.urls import reverse_lazy
from .forms import BookingForm
from django.views.generic import CreateView, ListView, DetailView


# Create your views here.

class CreateBooking(CreateView):
    model = Booking
    form_class = BookingForm
    success_url = reverse_lazy('blog:home')
    template_name = 'booking/booking_form.html'

class BookingDetail(DetailView):
    model = Booking
    template_name = 'contact/detail_booking.html'
    
    
class BookingList(ListView):
    model = Booking
    template_name = 'contact/list_bookings.html'



