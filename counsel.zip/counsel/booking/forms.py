from django import forms
from .models import Booking



class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['first_name', 'last_name', 'email', 'purpose', 'phone_number', 'date', 'time', 'message', 'whom_to_see']
    
    def __init__(self, *args, **kwargs):
        super(BookingForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].widget.attrs['class'] = 'form-control my-1'
        self.fields['last_name'].widget.attrs['class'] = 'form-control my-1'
        self.fields['email'].widget.attrs['class'] = 'form-control my-1'
        self.fields['phone_number'].widget.attrs['class'] = 'form-control my-1'
        self.fields['purpose'].widget.attrs['class'] = 'form-control my-1'
        self.fields['date'].widget.attrs['class'] = 'form-control my-1'
        self.fields['time'].widget.attrs['class'] = 'form-control my-1'
        self.fields['message'].widget.attrs['class'] = 'form-control my-1'
        self.fields['whom_to_see'].widget.attrs['class'] = 'form-control my-1'
    
    
    

    
    
    
 
 
 
 
    