from django.urls import path
from .views import CreateBooking, BookingDetail, BookingList


app_name = 'booking'


urlpatterns = [
    path('', CreateBooking.as_view(), name="create"),
    path('list/', BookingList.as_view(), name='list'),
    path('<int:pk>/', BookingDetail.as_view(), name='detail'),
    
    
    ]








