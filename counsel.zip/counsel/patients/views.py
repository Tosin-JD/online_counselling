from django.shortcuts import render
from django.views import generic
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import PatientRecord, Report
from .forms import ReportForm



# Create your views here.
class CreatePatientRecord(generic.CreateView, LoginRequiredMixin):
    model = PatientRecord
    template_name = 'patients/p_create.html'
    fields = ('patient',)


class PatientRecordUpdate(generic.UpdateView, LoginRequiredMixin):
    model = PatientRecord
    template_name = 'patients/p_detail.html'
    

class PatientRecordDelete(generic.UpdateView, LoginRequiredMixin):
    model = PatientRecord
    template_name = 'patients/p_delete.html'

    
class PatientRecordList(generic.ListView, LoginRequiredMixin):
    model = PatientRecord
    template_name = 'patients/p_list.html'
    
    
class PatientRecordDetail(generic.ListView, LoginRequiredMixin):
    model = PatientRecord
    template_name = 'patients/p_detail.html'
    

class CreateReport(generic.CreateView, LoginRequiredMixin):
    model = Report
    template_name = 'patients/r_create.html'
    form_class = ReportForm
    
class ReportList(generic.ListView, LoginRequiredMixin):
    model = Report
    template_name = 'patients/r_list.html'


class ReportUpdate(generic.UpdateView, LoginRequiredMixin):
    model = Report
    form_class = ReportForm
    template_name = 'patients/r_list.html'
    

class ReportDetail(generic.DetailView, LoginRequiredMixin):
    model = Report
    template_name = 'patients/r_list.html'
    
    
class ReportDelete(generic.DeleteView, LoginRequiredMixin):
    model = Report
    template_name = 'patients/p_delete.html'
    






















    
    
    
    