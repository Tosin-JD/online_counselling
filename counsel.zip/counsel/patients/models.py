from django.db import models
from accounts.models import Patient, Counsellor, MyUser
from django.urls import reverse_lazy

# Create your models here.


class PatientRecord(models.Model):
    patient = models.OneToOneField(Patient, on_delete=models.CASCADE)
    date_opened = models.DateField(auto_now_add=True)
    
    def __str__(self):
        return self.patient.matric_number
    
    def get_absolute_url():
        return reverse_lazy('patients:p_record_list')
    
class Report(models.Model):
    patient_report = models.OneToOneField(PatientRecord, on_delete=models.CASCADE)
    report_date = models.DateTimeField(auto_now_add=True)
    reporter = models.ForeignKey(Counsellor, on_delete=models.CASCADE)
    topic = models.CharField(max_length=50)
    content = models.TextField()
    details = models.TextField()
    conclusion = models.TextField()
    
    def __str__(self):
        return self.patient_report.patient.matric_number + " " + self.conclusion
    
    def get_absolute_url():
        return reverse_lazy('patients:p_report_list')
    
    
    
    
    
    