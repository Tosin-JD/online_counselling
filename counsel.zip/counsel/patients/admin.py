from django.contrib import admin
from .models import PatientRecord, Report


# Register your models here.
admin.site.register(PatientRecord)
admin.site.register(Report)






