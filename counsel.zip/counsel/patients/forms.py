from django import forms
from .models import Report


class ReportForm(forms.ModelForm):
    class Meta:
        model = Report
        fields = ('patient_report', 'reporter', 'topic', 'content', 'details', 'conclusion')
    
    def __init__(self, *args, **kwargs):
        super(ReportForm, self).__init__(*args, **kwargs)
        self.fields['patient_report'].widget.attrs['class'] = 'form-control my-1'
        self.fields['reporter'].widget.attrs['class'] = 'form-control my-1'
        self.fields['topic'].widget.attrs['class'] = 'form-control my-1'
        self.fields['content'].widget.attrs['class'] = 'form-control my-1'
        self.fields['details'].widget.attrs['class'] = 'form-control my-1'
        self.fields['conclusion'].widget.attrs['class'] = 'form-control my-1'
        








