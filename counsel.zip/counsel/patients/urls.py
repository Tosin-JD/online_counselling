from django.urls import path
from .views import *

app_name = 'patients'


urlpatterns = [
    path('', CreatePatientRecord.as_view(), name='p_record'),
    path('list/', PatientRecordList.as_view(), name='p_record_list'),
    path('<int:pk>/detail/', PatientRecordDetail.as_view(), name='p_record_detail'),
    path('<int:pk>/edit/', PatientRecordUpdate.as_view(), name='p_record_update'),
    path('<int:pk>/edit/', PatientRecordDelete.as_view(), name='p_record_delete'),
    
    path('report/', CreateReport.as_view(), name='p_report'),
    path('report-list/', ReportList.as_view(), name='p_report_list'),
    path('report/<int:pk>/detail/', ReportDetail.as_view(), name='p_report_detail'),
    path('report/<int:pk>/edit/', ReportUpdate.as_view(), name='p_report_update'),
    path('report/<int:pk>/delete/', ReportDelete.as_view(), name='p_report_delete'),
    
    ]