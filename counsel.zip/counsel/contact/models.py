from django.db import models
from django.utils.text import slugify
from django.urls import reverse_lazy

# Create your models here.


class Contact(models.Model):
    name = models.CharField(max_length=30)
    email = models.EmailField()
    slug = models.SlugField(blank=True)
    subject = models.CharField(max_length=255)
    message = models.TextField()
    
    def __str__(self):
        return "from " + self.name
    
    def get_absolute_url(self):
        return reverse_lazy('contact:create')
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.subject)
        super(Contact, self).save(*args, **kwargs)

