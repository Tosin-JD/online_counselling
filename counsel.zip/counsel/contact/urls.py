from django.urls import path
from contact.views import (CreateContact,
                           ContactList,
                           ContactDetail)
                           
                           
app_name = 'contact'

urlpatterns = [
    path('', CreateContact.as_view(), name='create'),
    path('list/', ContactList.as_view(), name='list'),
    path('<int:slug>/detail', ContactDetail.as_view(), name='detail'),
    
    
    
    ]
    
    
    
    
    