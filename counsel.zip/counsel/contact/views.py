from django.shortcuts import render
from .models import Contact
from django.views.generic import CreateView, DetailView, ListView



# Create your views here.
class CreateContact(CreateView):
    model = Contact
    fields = ('name', 'email', 'subject', 'message')


class ContactDetail(DetailView):
    model = Contact
    template_name = 'contact/detail_contact.html'
    
    
class ContactList(ListView):
    model = Contact
    template_name = 'contact/list_contacts.html'










