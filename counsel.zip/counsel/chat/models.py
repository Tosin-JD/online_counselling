from django.db import models
from accounts.models import MyUser
from django.urls import reverse_lazy


# Create your models here.
class Room(models.Model):
    """this is where users are to chat
    Counsellor to chat with Patient"""
    subscribers = models.ManyToManyField(MyUser, blank=True)
    name = models.CharField(max_length=30)
    
    def __str__(self):
        return self.name
        
    def get_absolute_url(self):
        return reverse_lazy('chat:room_detail', kwargs={'pk':self.id})
 

class Message(models.Model):
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE) #(2)
    room = models.ForeignKey(Room, on_delete=models.CASCADE) #(3)
    message = models.CharField(max_length=2500)
    timestamp = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.message
        
    def get_absolute_url(self):
        return reverse_lazy('chat:room_detail', kwargs={'pk':self.room_id})
 
   
    
    
    
    
    
    
    