from django.shortcuts import render, get_object_or_404
from django.urls import reverse_lazy
from django.views import generic
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import Room, Message


# Create your views here.
class CreateChatRoom(generic.CreateView, LoginRequiredMixin):
    model = Room
    fields = ('name',)
    template_name = 'chat/create_room.html'
    
    
class ListChatRoom(generic.ListView, LoginRequiredMixin):
    model = Room
    fields = ('subscribers', 'name')
    template_name = 'chat/list_room.html'


class DetailChatRoom(generic.DetailView, LoginRequiredMixin):
    model = Room
    fields = ('subscribers', 'name')
    template_name = 'chat/chat_room.html'
    
    
class CreateChat(generic.CreateView, LoginRequiredMixin):
    model = Message
    fields = ('user', 'room', 'message',)
    template_name = 'chat/create_chat.html'
   
class SendMessage(generic.CreateView, LoginRequiredMixin):
    model = Message
    fields = ('message',)
    template_name = 'chat/send_message.html'
    
    def get_context_data(self, **kwargs):
        self.room = get_object_or_404(Room, id=self.kwargs['room_id'])
        kwargs['room'] = self.room
        return super().get_context_data(**kwargs)

   
    def form_valid(self, form):
        self.room = get_object_or_404(Room, id=self.kwargs['room_id'])
        form.instance.user = self.request.user 
        form.instance.room = self.room
        
        response = super(SendMessage, self).form_valid(form)
        
        return response
        
    
class ChatList(generic.ListView, LoginRequiredMixin):
    model = Message
    template_name = 'chat/chat.html'
    
    
class ChatDelete(generic.DeleteView, LoginRequiredMixin):
    model = Message
    template_name = 'chat/chat_delete.html'
    success_url = 'chat:list'
    

class ChatRoomDelete(generic.DeleteView, LoginRequiredMixin):
    model = Message
    template_name = 'chat/room_delete.html'
    success_url = 'chat:list'
      
    
    
    
    
    
    
    
    
    
    
    