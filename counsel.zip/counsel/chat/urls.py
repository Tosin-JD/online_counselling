from django.urls import path
from .views import *



app_name = 'chat'


urlpatterns = [
        path('start/', CreateChatRoom.as_view(), name="start_chat"),
        path('create/', CreateChat.as_view(), name='create_chat'),
        path('', ChatList.as_view(), name='main'),
        path('<int:room_id>/send/', SendMessage.as_view(), name='send_message'),
        path('<int:pk>/', DetailChatRoom.as_view(), name='room_detail'),
        path('room/', ListChatRoom.as_view(), name='room_list'),
        path('room/<int:pk>/delete/', ChatRoomDelete.as_view(), name='room_delete'),
        path('<int:pk>/del/message/', ChatDelete.as_view(), name='chat_delete'),
    ]












