from django.db import models
from accounts.models import MyUser
from django.utils.text import slugify
from django.urls import reverse_lazy


# Create your models here.


STATUS = (
    (0,"Draft"),
    (1,"Publish")
)


class Category(models.Model):
    name = models.CharField(max_length=50)
    brief_description = models.TextField()
    
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name_plural = 'Categories'


class Post(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    title = models.CharField(max_length=200, unique=True)
    slug = models.SlugField(max_length=200, unique=True)
    author = models.ForeignKey(MyUser, on_delete= models.CASCADE,related_name='blog_posts')
    updated_on = models.DateTimeField(auto_now= True)
    content = models.TextField()
    summary = models.TextField()
    created_on = models.DateTimeField(auto_now_add=True)
    image = models.ImageField(upload_to='blog/')
    status = models.IntegerField(choices=STATUS, default=0)
    
    
    def get_absolute_url(self, **kwargs):
        return reverse_lazy('blog:post_detail', kwargs={'slug':self.slug})
        
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
        super(Post, self).save(*args, **kwargs)
    
    class Meta:
        ordering = ['-created_on']

    def __str__(self):
        return self.title