from django.urls import path
from . import views


app_name = 'blog'


urlpatterns = [
    path('', views.PostList.as_view(), name='home'),
    path('all/', views.CPostList.as_view(), name='post_list'),
    path('createpost/', views.CreatePost.as_view(), name='create_post'),
    path('<slug:slug>/', views.PostDetail.as_view(), name='post_detail'),
    path('<slug:slug>/edit/', views.EditPost.as_view(), name='post_edit'),
    path('<slug:slug>/publish/', views.PostDetail.as_view(), name='publish'),
    path('create/', views.PostNow.as_view(), name='post_now'),
    path('create-category/', views.CreateCategory.as_view(), name='create_cat'),
    path('categories/', views.CategoryList.as_view(), name='list_cat'),
    path('<int:pk>/category/', views.CategoryDetail.as_view(), name='detail_cat'),
    
    ]