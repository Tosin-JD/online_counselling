from django.forms import ModelForm

from .models import Post

class CreatePostForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(CreatePostForm, self).__init__(*args, **kwargs)
        self.fields['category'].widget.attrs['class'] = 'form-control my-1'
        self.fields['title'].widget.attrs['class'] = 'form-control my-1'
        self.fields['content'].widget.attrs['class'] = 'form-control my-1'
        self.fields['summary'].widget.attrs['class'] = 'form-control my-1'
        self.fields['image'].widget.attrs['class'] = 'form-control my-1'
        self.fields['status'].widget.attrs['class'] = 'form-control my-1'
        
    class Meta:
        model = Post
        fields = ('category', 'title', 'content', 'summary', 'image', 'status')
        



class PostForm(ModelForm):
    def __init__(self, *args, **kwargs):
        super(PostForm, self).__init__(*args, **kwargs)
        self.fields['title'].widget.attrs['class'] = 'form-control my-1'
        self.fields['content'].widget.attrs['class'] = 'form-control my-1'
        self.fields['summary'].widget.attrs['class'] = 'form-control my-1'
        self.fields['image'].widget.attrs['class'] = 'form-control my-1'
        self.fields['status'].widget.attrs['class'] = 'form-control my-1'
        
    class Meta:
        model = Post
        fields = ('title', 'content', 'summary', 'image', 'status')
        
   