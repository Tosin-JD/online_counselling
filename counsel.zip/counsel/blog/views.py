from django.shortcuts import (render, 
                              get_object_or_404,
                              )
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import (TemplateView,
                                  CreateView,
                                  DetailView,
                                  ListView,
                                  DeleteView,
                                  UpdateView)
from blog.models import Post, Category
from blog.forms import PostForm, CreatePostForm


# Create your views here.


class HomeView(ListView):
    queryset = Post.objects.filter(status=1).order_by('-created_on')
    template_name = 'index.html'
    
    def get_context_data(self, **kwargs):
        context = super(HomeView, self).get_context_data(**kwargs)
        context['category_list'] = Category.objects.all()
        # And so on for more models
        
        return context



class AboutView(TemplateView):
    template_name = 'about.html'


class CategoryList(ListView):
    template_name = 'blog/cat_list.html'
    model = Category
    
    def get_context_data(self, **kwargs):
        context = super(CategoryList, self).get_context_data(**kwargs)
        context['category_list'] = Category.objects.all()
        # And so on for more models
        
        return context

    

class CreateCategory(CreateView):
    template_name = 'blog/cat_create.html'
    model = Category
    fields = ('name', 'brief_description')

    
class CategoryDetail(DetailView):
    template_name = 'blog/cat_detail.html'
    model = Category
    
    def get_context_data(self, **kwargs):
        context = super(CategoryDetail, self).get_context_data(**kwargs)
        context['category_list'] = Category.objects.all()
        # And so on for more models
        
        return context

    

class PostList(ListView, LoginRequiredMixin):
    queryset = Post.objects.filter(status=1).order_by('-created_on')
    template_name = 'blog/post_list.html'
    
    def get_context_data(self, **kwargs):
        context = super(PostList, self).get_context_data(**kwargs)
        context['category_list'] = Category.objects.all()
        # And so on for more models
        
        return context


class CPostList(ListView):
    model = Post
    template_name = 'blog/cpost_list.html'
    
    def get_context_data(self, **kwargs):
        context = super(CPostList, self).get_context_data(**kwargs)
        context['category_list'] = Category.objects.all()
        # And so on for more models
        
        return context


class PostDetail(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super(PostDetail, self).get_context_data(**kwargs)
        context['category_list'] = Category.objects.all()
        # And so on for more models
        
        return context


    
class CreatePost(CreateView, LoginRequiredMixin):
    model = Post
    form_class = CreatePostForm
    template_name = 'blog/create_post.html'
    
      
    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)
        
        
class PostNow(UpdateView):
    model = Post
    template_name = 'blog/post_now.html'
    fields = 'status',
    
    
class EditPost(UpdateView):
    model = Post
    template_name = 'blog/edit_post.html'
    form_class = PostForm

"""
class NewCategoryPost(CreateView):
    model = Post
    template_name = 'blog/creat_new_post.html'
    
    def get_context_data(self, **kwargs):
        self.caterory = get_object_or_404(Category, id=self.kwargs['category_id'])
        kwargs['caterory'] = self.caterory
        return super().get_context_data(**kwargs)
      
    def form_valid(self, form):
        self.caterory =get_object_or_404(Category, id=self.kwargs['caterory_id'])
        form.instance.category = self.category
        return super().form_valid(form)
        
        
 """      
        
        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    