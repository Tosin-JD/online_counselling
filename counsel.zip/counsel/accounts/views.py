from django.shortcuts import render
from django.urls import reverse_lazy

from django.views import generic
from django.contrib.auth.mixins import LoginRequiredMixin
from accounts.models import MyUser, Counsellor, Patient
from accounts.forms import UserCreationForm

# Create your views here.
class SignUp(generic.CreateView):
    model = MyUser
    form_class = UserCreationForm
    template_name = "accounts/sign_up.html"
    success_url = reverse_lazy("accounts:login")
    
    
class ProfilePage(generic.TemplateView, LoginRequiredMixin):
    model = MyUser
    template_name = "accounts/profile.html"
    
    
class ThanksPage(generic.TemplateView):
    template_name = "accounts/thanks.html"
    


class CounsellorProfile(generic.DetailView, LoginRequiredMixin):
    model = Counsellor
    template_name = 'accounts/counsellor_profile.html'

    
class PatientProfile(generic.DetailView, LoginRequiredMixin):
    model = Patient
    template_name = 'accounts/patient_profile.html'
    
    
    
    
 
    
    
    
