from django.contrib import admin
from accounts.models import MyUser, Patient, Counsellor

# Register your models here.
admin.site.register(MyUser)
admin.site.register(Counsellor)
admin.site.register(Patient)





